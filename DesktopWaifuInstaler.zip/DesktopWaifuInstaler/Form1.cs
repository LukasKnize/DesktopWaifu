﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;

namespace DesktopWaifuInstaler
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int loaderSteps = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("1.0.3");
            comboBox1.Items.Add("1.0.4");
            loaderBar.Visible = false;
            loadingBarTimer.Enabled = false;
            string path = "./DesktopWaifu.exe";
            string[] dependencies = { "./DesktopWaifu.exe.config", "./DesktopWaifu.pdb", "./Newtonsoft.Json.dll", "./Newtonsoft.Json.xml" };
            if (File.Exists(path))
            {
                File.Delete(path);
                using (var client = new WebClient())
                {
                    client.DownloadFile("https://raw.githubusercontent.com/LukasKnize/DesktopWaifu/productionForInstaler/DesktopWaifu.exe", "DesktopWaifu.exe");
                }
            }
            else
            {
                using (var client = new WebClient())
                {
                    client.DownloadFile("https://raw.githubusercontent.com/LukasKnize/DesktopWaifu/productionForInstaler/DesktopWaifu.exe", "DesktopWaifu.exe");
                }
            }

            /*
             * pokud existují dependencies tak zkontroluje v souboru version.txt zda jsou nové dependecies (newDep na druhém řádku) a pokud ano tak je stáhne
             */

            foreach (string depends in dependencies)
            {
                if (File.Exists(depends))
                {
                    using (var client = new WebClient())
                    {
                        client.DownloadFile("https://raw.githubusercontent.com/LukasKnize/DesktopWaifu/productionForInstaler/version.txt", "version.txt");
                    }

                    string[] lines = File.ReadAllLines("./version.txt");
                    if (lines[1] == "newDep")
                    {
                        File.Delete(depends);
                        using (var client = new WebClient())
                        {
                            client.DownloadFile("https://raw.githubusercontent.com/LukasKnize/DesktopWaifu/productionForInstaler/" + depends, depends);
                        }
                    }
                }
                else
                {
                    using (var client = new WebClient())
                    {
                        client.DownloadFile("https://raw.githubusercontent.com/LukasKnize/DesktopWaifu/productionForInstaler/" + depends, depends);
                    }
                }
            }

            if (File.Exists("./version.txt"))
            {
                File.Delete("./version.txt");
            }




        }

        private void LoadingBarTimer_Tick(object sender, EventArgs e)
        {
            if (loaderSteps < 98)
            {
                loaderSteps++;
            }
            else
            {
                if (File.Exists("./DesktopWaifu.exe"))
                {
                    loaderSteps = 100;
                    loaderBar.Value = loaderSteps;
                    this.Close();
                }
            }
            
            loaderBar.Value = loaderSteps;
        }
    }
}
